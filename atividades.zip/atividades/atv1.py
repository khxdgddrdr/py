
num1 = int(input("Insira o primeiro número: "))
num2 = int(input("Insira o segundo número: "))

op = input("Escolha uma operação (+, -, *, /): ")

if op not in ['+', '-', '*', '/']:
    print("Operação inválida!")
else:
    if op == '+':
        print(f"{num1} + {num2} = {num1+num2}")
    elif op == '-':
        print(f"{num1} - {num2} = {num1-num2}")
    elif op == '*':
        print(f"{num1} * {num2} = {num1*num2}")
    else:  
        if num2 == 0:
            print("Não é possível dividir por zero!")
        else:
            print(f"{num1} / {num2} = {num1/num2}")